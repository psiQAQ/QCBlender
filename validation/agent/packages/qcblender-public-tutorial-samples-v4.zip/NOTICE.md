# Public tutorial samples v4

Gaussian-v2: native Gaussian GS2 53-frame IRC, TS27; unchanged Gaussian-v1 P01/P02/P03/P05 science. CC BY 4.0; attribution QCBlender contributors. Gaussian-v1 69 frames and v3 remain separately recoverable.
